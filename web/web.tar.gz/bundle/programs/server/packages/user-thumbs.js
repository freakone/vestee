(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['user-thumbs'] = {};

})();

//# sourceMappingURL=user-thumbs.js.map
