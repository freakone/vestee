(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var mqtt;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/spectrum_mqtt/packages/spectrum_mqtt.js                       //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/spectrum:mqtt/mqtt.js                                    //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
mqtt = Npm.require('mqtt');                                          // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////   // 11
                                                                          // 12
}).call(this);                                                            // 13
                                                                          // 14
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['spectrum:mqtt'] = {
  mqtt: mqtt
};

})();

//# sourceMappingURL=spectrum_mqtt.js.map
