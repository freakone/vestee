(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['highcharts:highcharts-meteor'] = {};

})();

//# sourceMappingURL=highcharts_highcharts-meteor.js.map
