(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Random = Package.random.Random;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

/* Package-scope variables */
var exposeLivedata, exposeMongoLivedata, MeteorX;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// packages/meteorhacks_meteorx/packages/meteorhacks_meteorx.js                                       //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
(function () {                                                                                        // 1
                                                                                                      // 2
//////////////////////////////////////////////////////////////////////////////////////////////////    // 3
//                                                                                              //    // 4
// packages/meteorhacks:meteorx/lib/livedata.js                                                 //    // 5
//                                                                                              //    // 6
//////////////////////////////////////////////////////////////////////////////////////////////////    // 7
                                                                                                //    // 8
exposeLivedata = function(namespace) {                                                          // 1  // 9
  //instrumenting session                                                                       // 2  // 10
  var fakeSocket = {send: function() {}, close: function() {}, headers: []};                    // 3  // 11
  var ddpConnectMessage = {msg: 'connect', version: 'pre1', support: ['pre1']};                 // 4  // 12
  Meteor.default_server._handleConnect(fakeSocket, ddpConnectMessage);                          // 5  // 13
                                                                                                // 6  // 14
  if(fakeSocket._meteorSession) { //for newer meteor versions                                   // 7  // 15
    namespace.Session = fakeSocket._meteorSession.constructor;                                  // 8  // 16
                                                                                                // 9  // 17
    exposeSubscription(fakeSocket._meteorSession, namespace);                                   // 10
    exposeSessionCollectionView(fakeSocket._meteorSession, namespace);                          // 11
                                                                                                // 12
    if(Meteor.default_server._closeSession) {                                                   // 13
      //0.7.x +                                                                                 // 14
      Meteor.default_server._closeSession(fakeSocket._meteorSession);                           // 15
    } else if(Meteor.default_server._destroySession) {                                          // 16
      //0.6.6.x                                                                                 // 17
      Meteor.default_server._destroySession(fakeSocket._meteorSession);                         // 18
    }                                                                                           // 19
  } else if(fakeSocket.meteor_session) { //support for 0.6.5.x                                  // 20
    namespace.Session = fakeSocket.meteor_session.constructor;                                  // 21
                                                                                                // 22
    //instrumenting subscription                                                                // 23
    exposeSubscription(fakeSocket.meteor_session, namespace);                                   // 24
    exposeSessionCollectionView(fakeSocket._meteorSession, namespace);                          // 25
                                                                                                // 26
    fakeSocket.meteor_session.detach(fakeSocket);                                               // 27
  } else {                                                                                      // 28
    console.error('expose: session exposing failed');                                           // 29
  }                                                                                             // 30
};                                                                                              // 31
                                                                                                // 32
function exposeSubscription(session, namespace) {                                               // 33
  var subId = Random.id();                                                                      // 34
  var publicationHandler = function() {this.ready()};                                           // 35
  var pubName = '__dummy_pub_' + Random.id();                                                   // 36
                                                                                                // 37
  session._startSubscription(publicationHandler, subId, [], pubName);                           // 38
  var subscription = session._namedSubs[subId];                                                 // 39
  namespace.Subscription = subscription.constructor;                                            // 40
                                                                                                // 41
  //cleaning up                                                                                 // 42
  session._stopSubscription(subId);                                                             // 43
}                                                                                               // 44
                                                                                                // 45
function exposeSessionCollectionView(session, namespace) {                                      // 46
  var documentView = session.getCollectionView();                                               // 47
  namespace.SessionCollectionView = documentView.constructor;                                   // 48
                                                                                                // 49
  var id = 'the-id';                                                                            // 50
  documentView.added('sample-handle', id, {aa: 10});                                            // 51
  namespace.SessionDocumentView = documentView.documents[id].constructor;                       // 52
}                                                                                               // 53
//////////////////////////////////////////////////////////////////////////////////////////////////    // 62
                                                                                                      // 63
}).call(this);                                                                                        // 64
                                                                                                      // 65
                                                                                                      // 66
                                                                                                      // 67
                                                                                                      // 68
                                                                                                      // 69
                                                                                                      // 70
(function () {                                                                                        // 71
                                                                                                      // 72
//////////////////////////////////////////////////////////////////////////////////////////////////    // 73
//                                                                                              //    // 74
// packages/meteorhacks:meteorx/lib/mongo-livedata.js                                           //    // 75
//                                                                                              //    // 76
//////////////////////////////////////////////////////////////////////////////////////////////////    // 77
                                                                                                //    // 78
exposeMongoLivedata = function(namespace) {                                                     // 1  // 79
  var coll = new Meteor.Collection('__dummy_coll_' + Random.id());                              // 2  // 80
  //we need wait until db get connected with meteor, .findOne() does that                       // 3  // 81
  coll.findOne();                                                                               // 4  // 82
                                                                                                // 5  // 83
  namespace.MongoConnection = MongoInternals.defaultRemoteCollectionDriver().mongo.constructor; // 6  // 84
  var cursor = coll.find();                                                                     // 7  // 85
  namespace.MongoCursor = cursor.constructor;                                                   // 8  // 86
}                                                                                               // 9  // 87
                                                                                                // 10
                                                                                                // 11
//////////////////////////////////////////////////////////////////////////////////////////////////    // 90
                                                                                                      // 91
}).call(this);                                                                                        // 92
                                                                                                      // 93
                                                                                                      // 94
                                                                                                      // 95
                                                                                                      // 96
                                                                                                      // 97
                                                                                                      // 98
(function () {                                                                                        // 99
                                                                                                      // 100
//////////////////////////////////////////////////////////////////////////////////////////////////    // 101
//                                                                                              //    // 102
// packages/meteorhacks:meteorx/lib/server.js                                                   //    // 103
//                                                                                              //    // 104
//////////////////////////////////////////////////////////////////////////////////////////////////    // 105
                                                                                                //    // 106
MeteorX = {};                                                                                   // 1  // 107
                                                                                                // 2  // 108
exposeLivedata(MeteorX);                                                                        // 3  // 109
exposeMongoLivedata(MeteorX);                                                                   // 4  // 110
                                                                                                // 5  // 111
//////////////////////////////////////////////////////////////////////////////////////////////////    // 112
                                                                                                      // 113
}).call(this);                                                                                        // 114
                                                                                                      // 115
////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['meteorhacks:meteorx'] = {
  MeteorX: MeteorX
};

})();

//# sourceMappingURL=meteorhacks_meteorx.js.map
