(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['yogiben:autoform-modals'] = {};

})();

//# sourceMappingURL=yogiben_autoform-modals.js.map
