(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var AccountsTemplates = Package['useraccounts:core'].AccountsTemplates;
var Accounts = Package['accounts-base'].Accounts;
var AccountsServer = Package['accounts-base'].AccountsServer;
var T9n = Package['softwarerero:accounts-t9n'].T9n;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['useraccounts:bootstrap'] = {};

})();

//# sourceMappingURL=useraccounts_bootstrap.js.map
