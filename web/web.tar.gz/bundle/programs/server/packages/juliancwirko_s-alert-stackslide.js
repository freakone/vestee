(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['juliancwirko:s-alert-stackslide'] = {};

})();

//# sourceMappingURL=juliancwirko_s-alert-stackslide.js.map
