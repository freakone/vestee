(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/mfactory_admin-lte/packages/mfactory_admin-lte.js        //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mfactory:admin-lte'] = {};

})();

//# sourceMappingURL=mfactory_admin-lte.js.map
