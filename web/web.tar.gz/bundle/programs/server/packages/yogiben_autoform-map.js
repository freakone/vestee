(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['yogiben:autoform-map'] = {};

})();

//# sourceMappingURL=yogiben_autoform-map.js.map
