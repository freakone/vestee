(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Highcharts;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['highcharts-container'] = {
  Highcharts: Highcharts
};

})();

//# sourceMappingURL=highcharts-container.js.map
