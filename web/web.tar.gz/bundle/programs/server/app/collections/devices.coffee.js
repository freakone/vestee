(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collections/devices.coffee.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Devices = new Meteor.Collection('devices');                       // 1
                                                                       //
Schemas.Devices = new SimpleSchema({                                   // 1
  name: {                                                              // 5
    type: String,                                                      // 6
    max: 100                                                           // 6
  },                                                                   //
  key: {                                                               // 5
    type: String,                                                      // 10
    max: 40,                                                           // 10
    unique: true,                                                      // 10
    autoValue: function() {                                            // 10
      if (this.isInsert) {                                             // 14
        return Random.hexString(30).toLowerCase();                     //
      }                                                                //
    }                                                                  //
  },                                                                   //
  createdAt: {                                                         // 5
    type: Date,                                                        // 18
    autoValue: function() {                                            // 18
      if (this.isInsert) {                                             // 20
        return new Date();                                             //
      }                                                                //
    }                                                                  //
  },                                                                   //
  owner: {                                                             // 5
    type: String,                                                      // 24
    regEx: SimpleSchema.RegEx.Id,                                      // 24
    autoValue: function() {                                            // 24
      if (this.isInsert) {                                             // 27
        return Meteor.userId();                                        //
      }                                                                //
    },                                                                 //
    autoform: {                                                        // 24
      options: function() {                                            // 30
        return _.map(Meteor.users.find().fetch(), function(user) {     //
          return {                                                     //
            label: user.emails[0].address,                             // 32
            value: user._id                                            // 32
          };                                                           //
        });                                                            //
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Devices.attachSchema(Schemas.Devices);                                 // 1
                                                                       //
this.StarterSchemas = Schemas;                                         // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=devices.coffee.js.map
