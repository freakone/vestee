(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collections/measurements.coffee.js                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Measurements = new Meteor.Collection('measurements');             // 1
                                                                       //
Measurements.before.insert(function(userId, doc) {                     // 1
  if (!Sensors.findOne({                                               // 4
    id: doc.id                                                         // 4
  })) {                                                                //
    throw new Meteor.Error(403, "No sensor with such ID");             // 4
  }                                                                    //
});                                                                    // 3
                                                                       //
Schemas.Measurements = new SimpleSchema({                              // 1
  id: {                                                                // 8
    type: Number,                                                      // 9
    min: 0,                                                            // 9
    max: 10                                                            // 9
  },                                                                   //
  value: {                                                             // 8
    type: Number,                                                      // 14
    decimal: true                                                      // 14
  },                                                                   //
  owner: {                                                             // 8
    type: String,                                                      // 18
    regEx: SimpleSchema.RegEx.Id                                       // 18
  },                                                                   //
  createdAt: {                                                         // 8
    optional: true,                                                    // 22
    type: Date,                                                        // 22
    autoValue: function() {                                            // 22
      if (this.isInsert) {                                             // 25
        return new Date();                                             //
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Measurements.attachSchema(Schemas.Measurements);                       // 1
                                                                       //
this.StarterSchemas = Schemas;                                         // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=measurements.coffee.js.map
