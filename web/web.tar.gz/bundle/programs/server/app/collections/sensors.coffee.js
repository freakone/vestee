(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collections/sensors.coffee.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
this.Sensors = new Meteor.Collection('sensors');                       // 1
                                                                       //
Sensors.before.insert(function(userId, doc) {                          // 1
  if (!Devices.findOne({                                               // 4
    _id: doc.owner                                                     // 4
  })) {                                                                //
    throw new Meteor.Error(403, "No such device");                     // 4
  }                                                                    //
});                                                                    // 3
                                                                       //
Schemas.Sensors = new SimpleSchema({                                   // 1
  name: {                                                              // 8
    type: String,                                                      // 9
    max: 100                                                           // 9
  },                                                                   //
  unit: {                                                              // 8
    type: String,                                                      // 13
    max: 10,                                                           // 13
    optional: true                                                     // 13
  },                                                                   //
  id: {                                                                // 8
    type: Number,                                                      // 18
    min: 0,                                                            // 18
    max: 10                                                            // 18
  },                                                                   //
  owner: {                                                             // 8
    type: String,                                                      // 23
    regEx: SimpleSchema.RegEx.Id                                       // 23
  },                                                                   //
  createdAt: {                                                         // 8
    optional: true,                                                    // 27
    type: Date,                                                        // 27
    autoValue: function() {                                            // 27
      if (this.isInsert) {                                             // 30
        return new Date();                                             //
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Measurements.attachSchema(Schemas.Measurements);                       // 1
                                                                       //
this.StarterSchemas = Schemas;                                         // 1
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=sensors.coffee.js.map
