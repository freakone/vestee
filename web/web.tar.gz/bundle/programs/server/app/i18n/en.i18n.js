(function(){var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"configName":"Vestee","configTitle":"Vestee","configSubtitle":"Smart fermentation vest","getstarted":"Get Started","dashboard":"Go to dashboard","learn":"Learn more","intro":"Make Meteor Apps. Fast.","how":"How It Works","step_1":"Step 1","step_1_text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit.","step_2":"Step 2","step_2_text":"Oratio me istius philosophi non offendit; Qua tu etiam inprudens utebare non numquam.","step_3":"Step 3","step_3_text":"Et ille ridens: Video, inquit, quid agas; Duo Reges: constructio interrete.","section_ipad_header":"A revolutionary product","section_ipad_text":"Do really cool stuff really quickly","section_ipad_btn":"Made by MeteorFactory","final_text":"Your life will be instantly better.","final_cta":"Take a look","favorite":"Favorite","admin":"Admin","profile":"Profile","account":"Account","signout":"Sign out","signup":"Sign up","login":"Log in","login2":"Login","edit_profile":"Edit Profile","not_found":"Nothing here.","add_key_btn":"Add new device","add_post_modal":"Add with a modal","add_post_modal_btn":"Add a new post","edit_post":"Edit post","delete":"Delete","favorites":"Favorites","device_view":"Device charts","account_details":"Account Details","delete_account":"Delete Account","delete_account_warn":"There's no coming back from this one","delete_account_warn2":"Are you sure you want to delete your account?","close":"Close","change_pswd":"Change Password","update":"Update","postTitle":"Title","postContent":"Content","postPicture":"Picture","profilePicture":"Profile Picture"};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

}).call(this);

//# sourceMappingURL=en.i18n.js.map
