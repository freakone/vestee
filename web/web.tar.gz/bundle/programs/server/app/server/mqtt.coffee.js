(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/mqtt.coffee.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var clients, server;                                                   // 1
                                                                       //
if (Meteor.isServer) {                                                 // 1
  clients = {};                                                        // 2
  server = mqtt.Server(Meteor.bindEnvironment(function(client) {       // 2
    client.on('connect', function(packet) {                            // 5
      clients[packet.clientId] = client;                               // 6
      client.id = packet.clientId;                                     // 6
      console.log("CONNECT: client id: " + client.id);                 // 6
      client.subscriptions = [];                                       // 6
      return client.connack({                                          //
        returnCode: 0                                                  // 10
      });                                                              //
    });                                                                //
    client.on('subscribe', Meteor.bindEnvironment(function(packet) {   // 5
      var granted, i, len, p, ref;                                     // 13
      granted = [];                                                    // 13
      console.log("SUBSCRIBE(%s): %j", client.id, packet);             // 13
      ref = packet.subscriptions;                                      // 15
      for (i = 0, len = ref.length; i < len; i++) {                    // 15
        p = ref[i];                                                    //
        if (Devices.findOne({                                          // 16
          key: p.topic                                                 // 16
        })) {                                                          //
          granted.push(p.qos);                                         // 17
          client.subscriptions.push(new RegExp(p.topic.replace('+', '[^\/]+').replace('#', '.+') + '$'));
        } else {                                                       //
          granted.push(128);                                           // 20
        }                                                              //
      }                                                                // 15
      return client.suback({                                           //
        messageId: packet.messageId,                                   // 21
        granted: granted                                               // 21
      });                                                              //
    }));                                                               //
    client.on('publish', Meteor.bindEnvironment(function(packet) {     // 5
      var c, i, len, params, ref, results, s;                          // 24
      params = JSON.parse(packet.payload);                             // 24
      Meteor.call('add_data', packet.topic, params.id, params.name, params.unit, params.value);
      ref = Object.keys(clients);                                      // 27
      results = [];                                                    // 27
      for (i = 0, len = ref.length; i < len; i++) {                    //
        c = ref[i];                                                    //
        c = clients[c];                                                // 28
        results.push((function() {                                     // 28
          var j, len1, ref1, results1;                                 //
          ref1 = c.subscriptions;                                      // 29
          results1 = [];                                               // 29
          for (j = 0, len1 = ref1.length; j < len1; j++) {             //
            s = ref1[j];                                               //
            if (s.test(packet.topic)) {                                // 30
              c.publish({                                              // 31
                topic: packet.topic,                                   // 31
                payload: packet.payload                                // 31
              });                                                      //
              break;                                                   // 32
            } else {                                                   //
              results1.push(void 0);                                   //
            }                                                          //
          }                                                            // 29
          return results1;                                             //
        })());                                                         //
      }                                                                // 27
      return results;                                                  //
    }));                                                               //
    client.on('pingreq', function(packet) {                            // 5
      return client.pingresp();                                        //
    });                                                                //
    client.on('disconnect', function(packet) {                         // 5
      return client.stream.end();                                      //
    });                                                                //
    client.on('close', function(err) {                                 // 5
      return delete clients[client.id];                                //
    });                                                                //
    return client.on('error', function(err) {                          //
      if (!clients[client.id]) {                                       // 44
        return;                                                        // 44
      }                                                                //
      return client.stream.end();                                      //
    });                                                                //
  }));                                                                 //
  server.listen(1883);                                                 // 2
}                                                                      //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=mqtt.coffee.js.map
