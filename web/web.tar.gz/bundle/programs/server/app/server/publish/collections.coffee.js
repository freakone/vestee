(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publish/collections.coffee.js                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
Meteor.publish('devices', function() {                                 // 1
  if (this.userId) {                                                   // 2
    return Devices.find({                                              //
      owner: this.userId                                               // 2
    });                                                                //
  }                                                                    //
});                                                                    // 1
                                                                       //
Meteor.publish('sensors', function(deviceId) {                         // 1
  if (deviceId) {                                                      // 5
    return Sensors.find({                                              //
      owner: deviceId                                                  // 5
    });                                                                //
  }                                                                    //
});                                                                    // 4
                                                                       //
Meteor.publish('measurements', function(deviceId, sensorId) {          // 1
  if (deviceId) {                                                      // 8
    return Measurements.find({                                         //
      owner: deviceId,                                                 // 8
      id: sensorId                                                     // 8
    }, {                                                               //
      sort: {                                                          // 8
        createdAt: -1                                                  // 8
      },                                                               //
      limit: 1000                                                      // 8
    });                                                                //
  }                                                                    //
});                                                                    // 7
                                                                       //
Meteor.methods({                                                       // 1
  add_data: function(api_key, id, name, unit, value) {                 // 11
    var device;                                                        // 12
    if (device = Devices.findOne({                                     // 12
      key: api_key                                                     // 12
    })) {                                                              //
      Sensors.upsert(Sensors.findOne({                                 // 13
        id: id,                                                        // 13
        owner: device._id                                              // 13
      }), {                                                            //
        id: id,                                                        // 13
        name: name,                                                    // 13
        unit: unit,                                                    // 13
        owner: device._id                                              // 13
      });                                                              //
      Measurements.insert({                                            // 13
        id: id,                                                        // 14
        value: value,                                                  // 14
        owner: device._id                                              // 14
      });                                                              //
      return "ok";                                                     // 15
    }                                                                  //
    return "invalid api key";                                          // 16
  }                                                                    //
});                                                                    //
                                                                       //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collections.coffee.js.map
